#pragma once
#include "../asset/asset_definitions.hpp"
#include "../asset/asset_registry.hpp"
#include "../game/game_ctx.hpp"
#include "../scene/scene.hpp"
#include "../scene/scene_registry.hpp"

class SplashScene : public Scene {
    static constexpr float SplashFade = 2.0f;
    static constexpr float SplashStay = 2.5f;
    static constexpr float SplashOffset = 0.5f;

    float timer_ = 0.0f;
    float alpha_ = 0.0f;

    TextureAsset* splashTex_ = nullptr;
public:
    explicit SplashScene(GameContext& ctx) : Scene(ctx) {}
    SceneId id() override { return SceneId::Splash; }

    void load() override {
        splashTex_ = ctx_.assets.load<TextureAsset>("splash", "splash.png");
    }

    void unload() override {
        ctx_.assets.unload("splash");
    }

    void update() override {
        timer_ += GetFrameTime();

        if (timer_ <= SplashFade) {
            alpha_ = timer_ / SplashFade;
        }
        else if (timer_ <= SplashFade + SplashStay) {
            alpha_ = 1.0f;
        }
        else if (timer_ <= SplashFade * 2 + SplashStay) {
            alpha_ = 1.0f - (timer_ - SplashFade - SplashStay) / SplashFade;
        }
        else {
            alpha_ = 0.0f;
        }

        if (timer_ >= SplashOffset + SplashStay + SplashFade * 2) {
            ctx_.scenes.loadScene(SceneId::Game);
        }
    }

    void render() override {
        DrawTexturePro()
    }
};
